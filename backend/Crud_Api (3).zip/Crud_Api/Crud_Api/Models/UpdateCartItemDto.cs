﻿namespace Crud_Api.Models
{
    public class UpdateCartItemDto
    {
        public int Quantity { get; set; }
    }
}
